package filevault;

public class ParsingFileVaultException extends Exception{

	    private static final long serialVersionUID = 1L;
	    
	    public ParsingFileVaultException (String s) {
	        super(s);
	    }
}
